/* Funktion som fetchar API från hemsidan, gör om det till json format, sedan lägger all data i en variabel.
Sedan kallar funktionen på en ytterligare funktion som visar all data, samt en console.log.
Finns också en catch utifall någonting blir fel. */
function connectAPI() {
    fetch('https://randomuser.me/api/')
        .then(res => res.json())
        .then(data => {
            const user = data.results[0];
            displayHTML(user);
            console.log(data);
        })
        .catch(error => console.error('Error fetching user:', error));
};

/* Funktion som gör min tomma HTML <main> till en variabel.
    Nästa steg tömmer den div:en för säkerhets skull.
    Jag skapar variablar som refererar till JSON-filen.
    Sedan skapar jag HTML element med document.CreateElement,
    och berättar vad för innehåll de ska ha och vart det hämtar det från.
    Jag lägger också till en klass till det nya elementet som skapas.*/

function displayHTML(user) {
    const userInfo = document.getElementById('user-info');

    userInfo.innerHTML = '';

    const userImage = user.picture.large;
    const userfName = user.name.first;
    const userlName = user.name.last;
    const userEmail = user.email;
    const userPhone = user.phone;
    const userGender = user.gender;

    const imgElement = document.createElement('img');
    imgElement.src = userImage;
    imgElement.className = "image"

    const fNameElement = document.createElement('div');
    fNameElement.textContent = `First name: \r\n`;
    fNameElement.textContent += `${userfName}`;
    fNameElement.className = "fName";

    const lNameElement = document.createElement('div');
    lNameElement.textContent = `Last name: \r\n`;
    lNameElement.textContent += `${userlName}`;
    lNameElement.className = "lName";

    const emailElement = document.createElement('div');
    emailElement.textContent = `Email: \r\n`;
    emailElement.textContent += `${userEmail}`;
    emailElement.className = "email";

    const phoneElement = document.createElement('div');
    phoneElement.textContent = `Phone: \r\n`;
    phoneElement.textContent += `${userPhone}`;
    phoneElement.className = "phone";

    const genderElement = document.createElement('div');
    genderElement.textContent = `Gender: \r\n`;
    genderElement.textContent += `${userGender}`;
    genderElement.className = "gender";

    /* Sist lägger jag till dessa nyskapta element till min tomma div så de visas på hemsidan.
    Klart! */

    userInfoDiv.appendChild(imgElement);
    userInfoDiv.appendChild(fNameElement);
    userInfoDiv.appendChild(lNameElement);
    userInfoDiv.appendChild(emailElement);
    userInfoDiv.appendChild(phoneElement);
    userInfoDiv.appendChild(genderElement);
};